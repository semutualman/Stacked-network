import os
import os.path
import sys
import time
import pickle
import h5py
import numpy as np

from tensorflow.keras.models import Model
from tensorflow.keras.layers import Flatten, Dense, Input, Conv1D, AveragePooling1D, BatchNormalization
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import ModelCheckpoint
from tensorflow.keras.utils import to_categorical
from sklearn import preprocessing
from tensorflow.python.keras import backend

from exploit_pred import *
from clr import OneCycleLR
from sklearn.model_selection import KFold, train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from tensorflow.keras.models import Sequential
import os
import tensorflow as tf

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
print("Num GPUs Available: ", len(tf.config.experimental.list_physical_devices('GPU')))

d_in = 'D:/Stacking/ASCAD/ASCAD_dataset/second_dataset/'
# second_level_train_set = np.load(d_in + "second_level_train_set.npy")
# test_nfolds_sets = np.load(d_in + "test_nfolds_sets.npy")
# Y_profiling = np.load(d_in + "Y_profiling.npy")
# Bestpred = np.load(d_in + "Best.npy")
# predictions1 = np.load(d_in + "predictions.npy")
# predictions2 = np.load("E:/EnsembleSCA-master/ascad/data/ASCAD.npy")
rank=np.load(d_in+"rank.npy")
rank1=np.load(d_in+"rank2.npy")
rank2=np.load(d_in+"rank3.npy")
rank3=np.load(d_in+"rank4.npy")
rank4=np.load(d_in+"rank5.npy")
rank5=np.load(d_in+"rank6.npy")
rank6=np.load(d_in+"rank7.npy")
rank7=np.load(d_in+"rank8.npy")
rank8=np.load(d_in+"rank9.npy")
rank9=np.load(d_in+"rank10.npy")
plot.rcParams['figure.figsize'] = (15, 6)
plot.ylim(-5, 150)
plot.grid(True)
# plot.plot(avg_rank, 'b')
plot.plot(rank, 'b', linestyle=':',label='Best Single Model')
plot.plot(rank1, 'r', linestyle=':',label='Ensembles 2 models')
plot.plot(rank2, 'g', linestyle=':',label='Ensembles 3 models')
plot.plot(rank3, 'b', label='Ensembles 4 models')
plot.plot(rank5, 'r', label='Ensembles 5 models')
plot.plot(rank4, 'k', label='Ensembles 6 models')
plot.plot(rank6, 'g', label='Ensembles 7 models')
plot.plot(rank7, color=(0.2, 0.5, 0.8), linestyle='--',label='Ensembles 8 models')
plot.plot(rank8, 'c', linestyle='--',label='Ensembles 9 models')
plot.plot(rank9, 'k', linestyle='--',label='Ensembles 10 models')
plot.xlabel('Number of traces', fontsize=24)
plot.ylabel('Guessing Entorpy', fontsize=24)
plot.yticks(fontproperties='Times New Roman', size=24)  # 设置大小及加粗
plot.xticks(fontproperties='Times New Roman', size=24)
plot.legend(fontsize=18)
plot.show()
print("\n t_GE = ")
print("\n############### Attack on Test Set Done #################\n")
